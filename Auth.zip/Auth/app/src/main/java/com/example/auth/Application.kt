package com.example.auth

import android.app.Application
import android.util.Log

class Auth : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.d("Inside","Auth")
        // initialize Amplify when application is starting
        Backend.initialize(applicationContext)
    }
}